# pokedex

## installer json-server 
`npm install -g json-server`

## lancer json-server
`json-server --watch db.json`
